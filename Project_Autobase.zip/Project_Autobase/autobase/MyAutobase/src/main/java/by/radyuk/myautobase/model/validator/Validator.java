package by.radyuk.myautobase.model.validator;

public interface Validator {
    boolean isValid(Object object);
}
